const Subscription = require('../models/Subscription');

// @route GET /api/subscriptions/vapid-public-key
const getVapidPublicKey = (req, res) => {
  res.json({ publicKey: process.env.VAPID_PUBLIC_KEY });
};

// @route POST /api/subscriptions/subscribe
const subscribe = async (req, res) => {
  try {
    const { endpoint, keys, device } = req.body;

    if (!endpoint || !keys || !keys.p256dh || !keys.auth) {
      return res.status(400).json({ message: 'Invalid subscription object' });
    }

    const existing = await Subscription.findOne({ endpoint });
    if (existing) {
      existing.user = req.user._id;
      existing.keys = keys;
      existing.device = device || existing.device;
      await existing.save();
      return res.status(200).json({ message: 'Subscription updated' });
    }

    await Subscription.create({
      user: req.user._id,
      endpoint,
      keys,
      device: device || 'unknown',
    });

    res.status(201).json({ message: 'Subscribed successfully' });
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

// @route POST /api/subscriptions/unsubscribe
const unsubscribe = async (req, res) => {
  try {
    const { endpoint } = req.body;
    await Subscription.deleteOne({ endpoint, user: req.user._id });
    res.json({ message: 'Unsubscribed successfully' });
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

module.exports = { getVapidPublicKey, subscribe, unsubscribe };
