const webpush = require('web-push');
const Notification = require('../models/Notification');
const Subscription = require('../models/Subscription');
const User = require('../models/User');

// @route POST /api/notifications/send   (admin only)
// body: { title, message, url, targetUserId (optional) }
const sendNotification = async (req, res) => {
  try {
    const { title, message, url, targetUserId } = req.body;

    if (!title || !message) {
      return res.status(400).json({ message: 'Title and message are required' });
    }

    let subscriptions;
    let audience = 'all';
    let recipient = null;

    if (targetUserId) {
      audience = 'single';
      recipient = targetUserId;
      subscriptions = await Subscription.find({ user: targetUserId });
    } else {
      subscriptions = await Subscription.find({});
    }

    const notification = await Notification.create({
      title,
      message,
      url: url || '/',
      sender: req.user._id,
      recipient,
      audience,
    });

    const payload = JSON.stringify({
      title,
      body: message,
      url: url || '/',
      notificationId: notification._id,
    });

    let delivered = 0;
    let failed = 0;

    // Send push to every stored subscription (browser or mobile PWA)
    const sendPromises = subscriptions.map(async (sub) => {
      const pushSubscription = {
        endpoint: sub.endpoint,
        keys: { p256dh: sub.keys.p256dh, auth: sub.keys.auth },
      };
      try {
        await webpush.sendNotification(pushSubscription, payload);
        delivered += 1;
      } catch (err) {
        failed += 1;
        // 410/404 means the subscription is no longer valid - clean it up
        if (err.statusCode === 410 || err.statusCode === 404) {
          await Subscription.deleteOne({ _id: sub._id });
        }
      }
    });

    await Promise.all(sendPromises);

    notification.deliveredCount = delivered;
    notification.failedCount = failed;
    await notification.save();

    // Also broadcast in real time to any connected clients via Socket.io
    const io = req.app.get('io');
    if (io) {
      if (targetUserId) {
        io.to(`user_${targetUserId}`).emit('newNotification', notification);
      } else {
        io.emit('newNotification', notification);
      }
    }

    res.status(201).json({
      message: 'Notification processed',
      delivered,
      failed,
      notification,
    });
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

// @route GET /api/notifications  (history, newest first)
const getNotifications = async (req, res) => {
  try {
    const filter =
      req.user.role === 'admin'
        ? {}
        : { $or: [{ audience: 'all' }, { recipient: req.user._id }] };

    const notifications = await Notification.find(filter)
      .sort({ createdAt: -1 })
      .limit(100)
      .populate('sender', 'name email');

    res.json(notifications);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

// @route GET /api/notifications/users  (admin only - to pick a target user)
const listUsers = async (req, res) => {
  try {
    const users = await User.find({}).select('name email faculty role');
    res.json(users);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

module.exports = { sendNotification, getNotifications, listUsers };
