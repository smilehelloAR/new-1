const express = require('express');
const router = express.Router();
const {
  sendNotification,
  getNotifications,
  listUsers,
} = require('../controllers/notificationController');
const { protect, adminOnly } = require('../middleware/auth');

router.post('/send', protect, adminOnly, sendNotification);
router.get('/', protect, getNotifications);
router.get('/users', protect, adminOnly, listUsers);

module.exports = router;
