const mongoose = require('mongoose');

const notificationSchema = new mongoose.Schema(
  {
    title: { type: String, required: true },
    message: { type: String, required: true },
    sender: { type: mongoose.Schema.Types.ObjectId, ref: 'User' },
    // If recipient is null, notification was broadcast to all users
    recipient: { type: mongoose.Schema.Types.ObjectId, ref: 'User', default: null },
    audience: { type: String, enum: ['all', 'single'], default: 'all' },
    url: { type: String, default: '/' }, // where to navigate when the notification is clicked
    read: { type: Boolean, default: false },
    deliveredCount: { type: Number, default: 0 },
    failedCount: { type: Number, default: 0 },
  },
  { timestamps: true }
);

module.exports = mongoose.model('Notification', notificationSchema);
