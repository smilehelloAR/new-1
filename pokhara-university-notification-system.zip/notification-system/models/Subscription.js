const mongoose = require('mongoose');

// Stores the Web Push subscription object the browser/mobile device gives us.
// This same schema works for desktop browsers and mobile browsers (PWA),
// since the Web Push standard is shared across both.
const subscriptionSchema = new mongoose.Schema(
  {
    user: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true },
    endpoint: { type: String, required: true, unique: true },
    keys: {
      p256dh: { type: String, required: true },
      auth: { type: String, required: true },
    },
    device: { type: String, default: 'unknown' }, // e.g. "Chrome / Android", "Edge / Desktop"
  },
  { timestamps: true }
);

module.exports = mongoose.model('Subscription', subscriptionSchema);
