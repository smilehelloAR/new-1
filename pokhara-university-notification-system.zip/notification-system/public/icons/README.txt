Place a 192x192 PNG icon here named icon-192.png for the push notification icon/badge.
Any university logo (e.g. Pokhara University logo) works well here.
