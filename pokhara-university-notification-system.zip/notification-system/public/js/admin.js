const API = '/api';
let token = localStorage.getItem('adminToken');

const $ = (id) => document.getElementById(id);

function setStatus(el, text, ok) {
  el.textContent = text;
  el.className = 'status ' + (ok ? 'ok' : 'err');
}

$('loginBtn').addEventListener('click', async () => {
  try {
    const res = await fetch(API + '/auth/login', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ email: $('email').value.trim(), password: $('password').value }),
    });
    const data = await res.json();
    if (!res.ok) throw new Error(data.message || 'Login failed');
    if (data.role !== 'admin') throw new Error('This account is not an admin');

    token = data.token;
    localStorage.setItem('adminToken', token);
    setStatus($('loginStatus'), 'Logged in as ' + data.name, true);
    afterLogin();
  } catch (err) {
    setStatus($('loginStatus'), err.message, false);
  }
});

async function afterLogin() {
  $('loginCard').classList.add('hidden');
  $('sendCard').classList.remove('hidden');
  $('historyCard').classList.remove('hidden');
  await loadUsers();
  await loadHistory();
}

async function loadUsers() {
  const res = await fetch(API + '/notifications/users', {
    headers: { Authorization: 'Bearer ' + token },
  });
  const users = await res.json();
  const select = $('targetSelect');
  users
    .filter((u) => u.role === 'student')
    .forEach((u) => {
      const opt = document.createElement('option');
      opt.value = u._id;
      opt.textContent = `${u.name} (${u.email})`;
      select.appendChild(opt);
    });
}

$('sendBtn').addEventListener('click', async () => {
  try {
    const body = {
      title: $('title').value.trim(),
      message: $('message').value.trim(),
      url: $('url').value.trim() || '/',
      targetUserId: $('targetSelect').value || undefined,
    };
    if (!body.title || !body.message) throw new Error('Title and message are required');

    const res = await fetch(API + '/notifications/send', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', Authorization: 'Bearer ' + token },
      body: JSON.stringify(body),
    });
    const data = await res.json();
    if (!res.ok) throw new Error(data.message || 'Failed to send');

    setStatus(
      $('sendStatus'),
      `Sent! Delivered to ${data.delivered} device(s), failed ${data.failed}.`,
      true
    );
    $('title').value = '';
    $('message').value = '';
    $('url').value = '';
    loadHistory();
  } catch (err) {
    setStatus($('sendStatus'), err.message, false);
  }
});

async function loadHistory() {
  const res = await fetch(API + '/notifications', {
    headers: { Authorization: 'Bearer ' + token },
  });
  const list = await res.json();
  const container = $('historyList');
  if (!list.length) {
    container.innerHTML = '<p style="color:var(--muted)">No notifications sent yet.</p>';
    return;
  }
  container.innerHTML = list
    .map(
      (n) => `
      <div class="notif-item">
        <div class="title">${escapeHtml(n.title)} <span class="tag">${n.audience}</span></div>
        <div>${escapeHtml(n.message)}</div>
        <div class="meta">
          ${new Date(n.createdAt).toLocaleString()} &middot;
          delivered ${n.deliveredCount}, failed ${n.failedCount}
        </div>
      </div>`
    )
    .join('');
}

function escapeHtml(str) {
  const div = document.createElement('div');
  div.textContent = str;
  return div.innerHTML;
}

if (token) afterLogin();
