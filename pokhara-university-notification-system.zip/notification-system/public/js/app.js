const API = '/api';
let token = localStorage.getItem('token');
let isRegisterMode = false;

const $ = (id) => document.getElementById(id);

// ---------- UI helpers ----------
function setStatus(el, text, ok) {
  el.textContent = text;
  el.className = 'status ' + (ok ? 'ok' : 'err');
}

function urlBase64ToUint8Array(base64String) {
  const padding = '='.repeat((4 - (base64String.length % 4)) % 4);
  const base64 = (base64String + padding).replace(/-/g, '+').replace(/_/g, '/');
  const rawData = atob(base64);
  return Uint8Array.from([...rawData].map((c) => c.charCodeAt(0)));
}

// ---------- Auth ----------
$('toggleAuth').addEventListener('click', () => {
  isRegisterMode = !isRegisterMode;
  $('registerFields').classList.toggle('hidden', !isRegisterMode);
  $('authTitle').textContent = isRegisterMode ? 'Register' : 'Login';
  $('submitAuth').textContent = isRegisterMode ? 'Register' : 'Login';
  $('toggleAuth').textContent = isRegisterMode
    ? 'Already have an account? Login'
    : 'Need an account? Register';
});

$('submitAuth').addEventListener('click', async () => {
  const email = $('email').value.trim();
  const password = $('password').value;
  const endpoint = isRegisterMode ? '/auth/register' : '/auth/login';
  const body = isRegisterMode
    ? { name: $('name').value.trim(), email, password, faculty: $('faculty').value.trim() }
    : { email, password };

  try {
    const res = await fetch(API + endpoint, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(body),
    });
    const data = await res.json();
    if (!res.ok) throw new Error(data.message || 'Something went wrong');

    token = data.token;
    localStorage.setItem('token', token);
    localStorage.setItem('userName', data.name);
    setStatus($('authStatus'), 'Success! Welcome ' + data.name, true);
    afterLogin(data.name);
  } catch (err) {
    setStatus($('authStatus'), err.message, false);
  }
});

$('logoutBtn').addEventListener('click', () => {
  localStorage.removeItem('token');
  location.reload();
});

function afterLogin(name) {
  $('authCard').classList.add('hidden');
  $('subscribeCard').classList.remove('hidden');
  $('notifCard').classList.remove('hidden');
  $('userLabel').textContent = 'Hi, ' + name;
  $('logoutBtn').classList.remove('hidden');
  loadNotifications();
  connectSocket();
}

// ---------- Push subscription ----------
$('subscribeBtn').addEventListener('click', async () => {
  try {
    if (!('serviceWorker' in navigator) || !('PushManager' in window)) {
      throw new Error('Push notifications are not supported in this browser');
    }

    const permission = await Notification.requestPermission();
    if (permission !== 'granted') throw new Error('Permission denied');

    const reg = await navigator.serviceWorker.register('/sw.js');
    const keyRes = await fetch(API + '/subscriptions/vapid-public-key');
    const { publicKey } = await keyRes.json();

    const subscription = await reg.pushManager.subscribe({
      userVisibleOnly: true,
      applicationServerKey: urlBase64ToUint8Array(publicKey),
    });

    const device = navigator.userAgent.includes('Mobile') ? 'Mobile Browser' : 'Desktop Browser';

    const res = await fetch(API + '/subscriptions/subscribe', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', Authorization: 'Bearer ' + token },
      body: JSON.stringify({ ...subscription.toJSON(), device }),
    });
    if (!res.ok) throw new Error('Could not save subscription');

    setStatus($('subStatus'), 'Notifications enabled! You will now receive push alerts.', true);
  } catch (err) {
    setStatus($('subStatus'), err.message, false);
  }
});

// ---------- Notification history ----------
async function loadNotifications() {
  try {
    const res = await fetch(API + '/notifications', {
      headers: { Authorization: 'Bearer ' + token },
    });
    const list = await res.json();
    renderNotifications(list);
  } catch (err) {
    console.error(err);
  }
}

function renderNotifications(list) {
  const container = $('notifList');
  if (!list.length) {
    container.innerHTML = '<p style="color:var(--muted)">No notifications yet.</p>';
    return;
  }
  container.innerHTML = list
    .map(
      (n) => `
      <div class="notif-item">
        <div class="title">${escapeHtml(n.title)}</div>
        <div>${escapeHtml(n.message)}</div>
        <div class="meta">${new Date(n.createdAt).toLocaleString()}</div>
      </div>`
    )
    .join('');
}

function escapeHtml(str) {
  const div = document.createElement('div');
  div.textContent = str;
  return div.innerHTML;
}

// ---------- Real-time via Socket.io (in-app, live update) ----------
function connectSocket() {
  const socket = io();
  socket.on('connect', () => socket.emit('authenticate', token));
  socket.on('newNotification', () => loadNotifications());
}

// ---------- Init ----------
if (token) {
  afterLogin(localStorage.getItem('userName') || 'User');
}
