// Service Worker - handles push events even when the site tab is closed.
// This is what makes notifications work like "mobile-style" push on browsers.

self.addEventListener('push', (event) => {
  let data = { title: 'Pokhara University', body: 'You have a new notification', url: '/' };
  try {
    data = event.data.json();
  } catch (e) {
    // fallback to defaults above
  }

  const options = {
    body: data.body,
    icon: '/icons/icon-192.png',
    badge: '/icons/icon-192.png',
    data: { url: data.url || '/' },
    vibrate: [100, 50, 100],
  };

  event.waitUntil(self.registration.showNotification(data.title, options));
});

self.addEventListener('notificationclick', (event) => {
  event.notification.close();
  const url = event.notification.data && event.notification.data.url ? event.notification.data.url : '/';

  event.waitUntil(
    clients.matchAll({ type: 'window' }).then((clientList) => {
      for (const client of clientList) {
        if (client.url.includes(url) && 'focus' in client) {
          return client.focus();
        }
      }
      if (clients.openWindow) {
        return clients.openWindow(url);
      }
    })
  );
});
