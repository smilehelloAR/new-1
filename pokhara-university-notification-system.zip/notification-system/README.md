# Real-Time Push Notification System
### A Project for Pokhara University

## 1. Project Overview
This is a full-stack **Push Notification System** built with **Node.js, Express, and MongoDB**.
It allows an administrator (e.g. university department) to send instant notifications
(announcements, exam routines, results, events) to all students or a specific student.
Notifications are delivered as **native browser/mobile push notifications** using the
**Web Push protocol (VAPID)**, so students receive alerts even when the site tab is closed,
and are also updated live in-app via **Socket.io** while the page is open.

## 2. Objectives
- Design and implement a centralized notification system for a university.
- Allow real-time, instant delivery of notifications to students' devices.
- Provide an admin panel to broadcast or target notifications.
- Maintain a notification history log in the database.
- Demonstrate use of Web Push API, JWT authentication, and REST API design.

## 3. Tech Stack
| Layer | Technology |
|---|---|
| Backend | Node.js, Express.js |
| Database | MongoDB (Mongoose ODM) |
| Real-time | Socket.io |
| Push Notifications | Web Push API (`web-push` library, VAPID keys) |
| Authentication | JWT (JSON Web Token), bcrypt password hashing |
| Frontend | HTML, CSS, Vanilla JavaScript (no framework needed) |

## 4. Features
- Student registration & login (JWT-secured)
- Browser/mobile push notification subscription (Service Worker)
- Admin panel to send notifications to **all students** or **one student**
- Real-time in-app notification updates (Socket.io)
- Notification history with delivered/failed counts
- Auto-cleanup of expired/invalid push subscriptions
- First registered user automatically becomes Admin (for easy demo setup)

## 5. Folder Structure
```
notification-system/
├── config/db.js               # MongoDB connection
├── models/                    # User, Subscription, Notification schemas
├── controllers/                # Business logic
├── routes/                     # API routes
├── middleware/auth.js          # JWT protect + admin-only middleware
├── utils/                      # Token & VAPID key generators
├── public/                     # Frontend (student + admin pages)
│   ├── index.html               # Student page
│   ├── admin.html                # Admin page
│   ├── sw.js                     # Service worker (handles push events)
│   ├── css/style.css
│   └── js/ (app.js, admin.js)
├── server.js                   # Entry point
├── package.json
└── .env.example
```

## 6. Installation & Setup

### Step 1 — Install dependencies
```bash
cd notification-system
npm install
```

### Step 2 — Configure environment variables
Copy `.env.example` to `.env`:
```bash
cp .env.example .env
```

### Step 3 — Generate VAPID keys (required for push notifications)
```bash
npm run generate-vapid
```
Copy the printed `VAPID_PUBLIC_KEY` and `VAPID_PRIVATE_KEY` into your `.env` file.

### Step 4 — Start MongoDB
Make sure MongoDB is running locally, or set `MONGO_URI` in `.env` to a
MongoDB Atlas connection string.

### Step 5 — Run the server
```bash
npm run dev     # with nodemon (auto-restart)
# or
npm start
```

Server runs at: `http://localhost:5000`

## 7. Usage / Demo Flow
1. Open `http://localhost:5000` → Register a student account.
   *(The very first account registered on the system automatically becomes an Admin.)*
2. Click **"Enable Notifications"** and allow the browser permission prompt.
3. Open `http://localhost:5000/admin.html` in another tab/browser and log in
   with the admin account you created first.
4. Select a target student (or leave as "All Students"), write a title & message, and send.
5. The student instantly receives a **native OS push notification**
   (even if the student's tab is closed) and the in-app list updates live.

## 8. Notes for Deployment / Mobile Push
- This uses the **W3C Web Push standard**, which works identically on desktop
  Chrome/Edge/Firefox and on mobile browsers (Chrome for Android, and Safari
  on iOS 16.4+), including when the site is installed as a PWA on a phone's home screen.
- For a native Android/iOS app instead of a mobile browser/PWA, the same
  `Notification` model and `/api/notifications/send` endpoint can be reused —
  simply swap the `web-push` delivery step for **Firebase Cloud Messaging (FCM)**
  or **Apple Push Notification service (APNs)**, storing FCM/APNs tokens in the
  `Subscription` model instead of Web Push endpoints.
- For production, serve the app over HTTPS (required by the Push API), set a
  strong `JWT_SECRET`, and use a managed MongoDB (e.g. MongoDB Atlas).

## 9. Possible Future Enhancements
- Email notification channel (Nodemailer) alongside push
- SMS channel (Twilio/Sparrow SMS) for critical alerts
- Role-based notification categories (exam, event, emergency)
- Notification scheduling (send at a future date/time)
- Read/unread tracking per student

## 10. Author
Prepared as a project submission for **Pokhara University**.
*(Add your name, roll number, faculty/program, and submission date here.)*
