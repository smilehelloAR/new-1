// Run this once with: npm run generate-vapid
// Copy the output into your .env file (VAPID_PUBLIC_KEY / VAPID_PRIVATE_KEY)
const webpush = require('web-push');

const vapidKeys = webpush.generateVAPIDKeys();

console.log('\n=== VAPID Keys Generated ===\n');
console.log('VAPID_PUBLIC_KEY=' + vapidKeys.publicKey);
console.log('VAPID_PRIVATE_KEY=' + vapidKeys.privateKey);
console.log('\nPaste these two lines into your .env file.\n');
