# ecommerce — Rust backend scaffold (Amazon/Daraz/Pathao-style)

A working Axum-based REST API skeleton for an e-commerce marketplace: users,
product catalog with search/filter, cart, and checkout → orders.

Storage is **in-memory** (`RwLock<HashMap<..>>` in `src/state.rs`) so the
project runs with zero external setup. Swap it for Postgres (`sqlx`, already
commented in `Cargo.toml`) and Redis when you're ready for persistence —
the handler signatures won't need to change, only `state.rs` and the
handler bodies that touch `db`.

## Run

```bash
cp .env.example .env      # edit JWT_SECRET
cargo run
```

Server listens on `http://0.0.0.0:3000`.

> Note: this was written offline and has not been compiled in this
> environment (no network access to crates.io here). The code is structured
> to compile cleanly against the pinned dependency versions in `Cargo.toml`,
> but run `cargo build` yourself first and fix any version-drift errors —
> Axum/axum-extra especially move fast between minor versions.

## Project layout

```
src/
  main.rs               router + server startup
  state.rs               AppState (in-memory "database")
  models.rs               Product, User, Cart, Order, request/response DTOs
  auth.rs                 JWT creation + AuthUser extractor (Bearer token)
  handlers/
    auth.rs                register, login (Argon2 password hashing)
    products.rs             list (search/filter/paginate), get, create, delete
    cart.rs                  get, add, remove
    orders.rs                checkout (cart → order, stock deduction), history
```

## API

| Method | Path                     | Auth | Description |
|---|---|---|---|
| POST | `/api/auth/register` | — | create account |
| POST | `/api/auth/login` | — | get JWT |
| GET  | `/api/products` | — | `?q=&category=&min_price=&max_price=&page=&page_size=` |
| GET  | `/api/products/:id` | — | product detail |
| POST | `/api/products` | vendor/admin | create listing |
| DELETE | `/api/products/:id` | owner/admin | remove listing |
| GET  | `/api/cart` | user | view cart |
| POST | `/api/cart` | user | `{product_id, quantity}` |
| DELETE | `/api/cart/:product_id` | user | remove item |
| POST | `/api/orders/checkout` | user | `{shipping_address}` → creates order from cart |
| GET  | `/api/orders` | user | order history |

Auth: send `Authorization: Bearer <token>` from register/login.

## Next steps for a production build

- Swap in-memory `Db` for Postgres via `sqlx` (migrations, connection pool)
- Add Redis for cart/session caching and rate limiting
- Integrate a payment gateway (Stripe, or bKash/Nagad/eSewa via `reqwest`)
- Add product search via Meilisearch/Elasticsearch instead of the naive
  in-memory filter in `list_products`
- Add pagination metadata (total count) to `/products` response
- Add refresh tokens / token revocation
- Rate limiting + request validation middleware (`tower-http`, `validator`)
- Image upload to S3-compatible storage
