use std::collections::HashMap;
use std::sync::Arc;
use tokio::sync::RwLock;
use uuid::Uuid;

use crate::models::{Cart, Order, Product, User};

#[derive(Default)]
pub struct Db {
    pub products: HashMap<Uuid, Product>,
    pub users: HashMap<Uuid, User>,
    pub users_by_email: HashMap<String, Uuid>,
    pub carts: HashMap<Uuid, Cart>, // keyed by user_id
    pub orders: HashMap<Uuid, Order>,
}

#[derive(Clone)]
pub struct AppState {
    pub db: Arc<RwLock<Db>>,
    pub jwt_secret: Arc<String>,
}

impl AppState {
    pub fn new(jwt_secret: String) -> Self {
        Self {
            db: Arc::new(RwLock::new(Db::default())),
            jwt_secret: Arc::new(jwt_secret),
        }
    }
}
