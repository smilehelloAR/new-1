use axum::{
    extract::{Path, Query, State},
    http::StatusCode,
    Json,
};
use chrono::Utc;
use rust_decimal::prelude::ToPrimitive;
use serde::Deserialize;
use uuid::Uuid;

use crate::auth::AuthUser;
use crate::models::{CreateProductRequest, Product, UserRole};
use crate::state::AppState;

#[derive(Debug, Deserialize)]
pub struct ProductQuery {
    pub q: Option<String>,
    pub category: Option<String>,
    pub min_price: Option<f64>,
    pub max_price: Option<f64>,
    pub page: Option<usize>,
    pub page_size: Option<usize>,
}

pub async fn list_products(
    State(state): State<AppState>,
    Query(params): Query<ProductQuery>,
) -> Json<Vec<Product>> {
    let db = state.db.read().await;

    let mut results: Vec<Product> = db
        .products
        .values()
        .filter(|p| {
            let matches_q = params
                .q
                .as_ref()
                .map(|q| p.name.to_lowercase().contains(&q.to_lowercase()))
                .unwrap_or(true);
            let matches_cat = params
                .category
                .as_ref()
                .map(|c| p.category.eq_ignore_ascii_case(c))
                .unwrap_or(true);
            let price = p.price.to_f64().unwrap_or(0.0);
            let matches_min = params.min_price.map(|min| price >= min).unwrap_or(true);
            let matches_max = params.max_price.map(|max| price <= max).unwrap_or(true);
            matches_q && matches_cat && matches_min && matches_max
        })
        .cloned()
        .collect();

    results.sort_by(|a, b| b.created_at.cmp(&a.created_at));

    let page = params.page.unwrap_or(1).max(1);
    let page_size = params.page_size.unwrap_or(20).clamp(1, 100);
    let start = (page - 1) * page_size;

    let paged = results.into_iter().skip(start).take(page_size).collect();
    Json(paged)
}

pub async fn get_product(
    State(state): State<AppState>,
    Path(id): Path<Uuid>,
) -> Result<Json<Product>, StatusCode> {
    let db = state.db.read().await;
    db.products.get(&id).cloned().map(Json).ok_or(StatusCode::NOT_FOUND)
}

pub async fn create_product(
    State(state): State<AppState>,
    auth: AuthUser,
    Json(req): Json<CreateProductRequest>,
) -> Result<Json<Product>, (StatusCode, String)> {
    if !matches!(auth.role, UserRole::Vendor | UserRole::Admin) {
        return Err((StatusCode::FORBIDDEN, "only vendors can list products".into()));
    }

    let product = Product {
        id: Uuid::new_v4(),
        name: req.name,
        description: req.description,
        price: req.price,
        currency: "USD".to_string(),
        category: req.category,
        stock: req.stock,
        image_url: req.image_url,
        vendor_id: auth.user_id,
        rating: 0.0,
        created_at: Utc::now(),
    };

    let mut db = state.db.write().await;
    db.products.insert(product.id, product.clone());
    Ok(Json(product))
}

pub async fn delete_product(
    State(state): State<AppState>,
    auth: AuthUser,
    Path(id): Path<Uuid>,
) -> Result<StatusCode, (StatusCode, String)> {
    let mut db = state.db.write().await;
    let product = db.products.get(&id).ok_or((StatusCode::NOT_FOUND, "product not found".into()))?;

    if product.vendor_id != auth.user_id && auth.role != UserRole::Admin {
        return Err((StatusCode::FORBIDDEN, "not your product".into()));
    }

    db.products.remove(&id);
    Ok(StatusCode::NO_CONTENT)
}
