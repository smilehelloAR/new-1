use axum::{extract::{Path, State}, http::StatusCode, Json};
use uuid::Uuid;

use crate::auth::AuthUser;
use crate::models::{AddToCartRequest, Cart};
use crate::state::AppState;

pub async fn get_cart(State(state): State<AppState>, auth: AuthUser) -> Json<Cart> {
    let db = state.db.read().await;
    Json(db.carts.get(&auth.user_id).cloned().unwrap_or_default())
}

pub async fn add_to_cart(
    State(state): State<AppState>,
    auth: AuthUser,
    Json(req): Json<AddToCartRequest>,
) -> Result<Json<Cart>, (StatusCode, String)> {
    if req.quantity <= 0 {
        return Err((StatusCode::BAD_REQUEST, "quantity must be positive".into()));
    }

    let mut db = state.db.write().await;

    let stock = db
        .products
        .get(&req.product_id)
        .ok_or((StatusCode::NOT_FOUND, "product not found".to_string()))?
        .stock;

    if stock < req.quantity {
        return Err((StatusCode::BAD_REQUEST, "not enough stock".into()));
    }

    let cart = db.carts.entry(auth.user_id).or_default();
    if let Some(item) = cart.items.iter_mut().find(|i| i.product_id == req.product_id) {
        item.quantity += req.quantity;
    } else {
        cart.items.push(crate::models::CartItem {
            product_id: req.product_id,
            quantity: req.quantity,
        });
    }

    Ok(Json(cart.clone()))
}

pub async fn remove_from_cart(
    State(state): State<AppState>,
    auth: AuthUser,
    Path(product_id): Path<Uuid>,
) -> Json<Cart> {
    let mut db = state.db.write().await;
    let cart = db.carts.entry(auth.user_id).or_default();
    cart.items.retain(|i| i.product_id != product_id);
    Json(cart.clone())
}
