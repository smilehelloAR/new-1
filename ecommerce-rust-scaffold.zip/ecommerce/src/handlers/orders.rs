use axum::{extract::State, http::StatusCode, Json};
use chrono::Utc;
use rust_decimal::Decimal;
use uuid::Uuid;

use crate::auth::AuthUser;
use crate::models::{CheckoutRequest, Order, OrderItem, OrderStatus};
use crate::state::AppState;

pub async fn checkout(
    State(state): State<AppState>,
    auth: AuthUser,
    Json(req): Json<CheckoutRequest>,
) -> Result<Json<Order>, (StatusCode, String)> {
    let mut db = state.db.write().await;

    let cart = db
        .carts
        .get(&auth.user_id)
        .cloned()
        .unwrap_or_default();

    if cart.items.is_empty() {
        return Err((StatusCode::BAD_REQUEST, "cart is empty".into()));
    }

    let mut order_items = Vec::new();
    let mut total = Decimal::ZERO;

    // Validate stock and build order items first (no mutation yet).
    for item in &cart.items {
        let product = db
            .products
            .get(&item.product_id)
            .ok_or((StatusCode::NOT_FOUND, format!("product {} no longer exists", item.product_id)))?;

        if product.stock < item.quantity {
            return Err((
                StatusCode::BAD_REQUEST,
                format!("not enough stock for {}", product.name),
            ));
        }

        total += product.price * Decimal::from(item.quantity);
        order_items.push(OrderItem {
            product_id: product.id,
            name: product.name.clone(),
            quantity: item.quantity,
            unit_price: product.price,
        });
    }

    // Now that everything is validated, deduct stock.
    for item in &cart.items {
        if let Some(product) = db.products.get_mut(&item.product_id) {
            product.stock -= item.quantity;
        }
    }

    let order = Order {
        id: Uuid::new_v4(),
        user_id: auth.user_id,
        items: order_items,
        total,
        status: OrderStatus::Pending,
        shipping_address: req.shipping_address,
        created_at: Utc::now(),
    };

    db.orders.insert(order.id, order.clone());
    db.carts.remove(&auth.user_id);

    Ok(Json(order))
}

pub async fn list_my_orders(State(state): State<AppState>, auth: AuthUser) -> Json<Vec<Order>> {
    let db = state.db.read().await;
    let mut orders: Vec<Order> = db
        .orders
        .values()
        .filter(|o| o.user_id == auth.user_id)
        .cloned()
        .collect();
    orders.sort_by(|a, b| b.created_at.cmp(&a.created_at));
    Json(orders)
}
