use argon2::password_hash::{rand_core::OsRng, PasswordHash, PasswordHasher, PasswordVerifier, SaltString};
use argon2::Argon2;
use axum::{extract::State, http::StatusCode, Json};
use chrono::Utc;
use uuid::Uuid;

use crate::auth::create_token;
use crate::models::{AuthResponse, LoginRequest, RegisterRequest, User, UserRole};
use crate::state::AppState;

pub async fn register(
    State(state): State<AppState>,
    Json(req): Json<RegisterRequest>,
) -> Result<Json<AuthResponse>, (StatusCode, String)> {
    if req.password.len() < 8 {
        return Err((StatusCode::BAD_REQUEST, "password must be at least 8 characters".into()));
    }

    let mut db = state.db.write().await;
    if db.users_by_email.contains_key(&req.email) {
        return Err((StatusCode::CONFLICT, "email already registered".into()));
    }

    let salt = SaltString::generate(&mut OsRng);
    let password_hash = Argon2::default()
        .hash_password(req.password.as_bytes(), &salt)
        .map_err(|_| (StatusCode::INTERNAL_SERVER_ERROR, "failed to hash password".into()))?
        .to_string();

    let user = User {
        id: Uuid::new_v4(),
        name: req.name,
        email: req.email.clone(),
        password_hash,
        role: UserRole::Customer,
        created_at: Utc::now(),
    };

    let token = create_token(user.id, user.role, &state.jwt_secret)
        .map_err(|_| (StatusCode::INTERNAL_SERVER_ERROR, "failed to create token".into()))?;

    db.users_by_email.insert(user.email.clone(), user.id);
    db.users.insert(user.id, user.clone());

    Ok(Json(AuthResponse { token, user }))
}

pub async fn login(
    State(state): State<AppState>,
    Json(req): Json<LoginRequest>,
) -> Result<Json<AuthResponse>, (StatusCode, String)> {
    let db = state.db.read().await;

    let user_id = db
        .users_by_email
        .get(&req.email)
        .ok_or((StatusCode::UNAUTHORIZED, "invalid email or password".to_string()))?;

    let user = db.users.get(user_id).cloned().unwrap();

    let parsed_hash = PasswordHash::new(&user.password_hash)
        .map_err(|_| (StatusCode::INTERNAL_SERVER_ERROR, "corrupt password hash".to_string()))?;

    Argon2::default()
        .verify_password(req.password.as_bytes(), &parsed_hash)
        .map_err(|_| (StatusCode::UNAUTHORIZED, "invalid email or password".to_string()))?;

    let token = create_token(user.id, user.role, &state.jwt_secret)
        .map_err(|_| (StatusCode::INTERNAL_SERVER_ERROR, "failed to create token".to_string()))?;

    Ok(Json(AuthResponse { token, user }))
}
