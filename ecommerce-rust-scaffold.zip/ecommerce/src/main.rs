mod auth;
mod handlers;
mod models;
mod state;

use axum::{
    routing::{get, post},
    Router,
};
use std::env;
use tower_http::cors::CorsLayer;
use tower_http::trace::TraceLayer;
use tracing_subscriber::{layer::SubscriberExt, util::SubscriberInitExt};

use state::AppState;

#[tokio::main]
async fn main() {
    dotenvy::dotenv().ok();

    tracing_subscriber::registry()
        .with(tracing_subscriber::EnvFilter::new(
            env::var("RUST_LOG").unwrap_or_else(|_| "info,ecommerce=debug".into()),
        ))
        .with(tracing_subscriber::fmt::layer())
        .init();

    let jwt_secret = env::var("JWT_SECRET").unwrap_or_else(|_| "dev-secret-change-me".to_string());
    let state = AppState::new(jwt_secret);

    let api_routes = Router::new()
        .route("/auth/register", post(handlers::auth::register))
        .route("/auth/login", post(handlers::auth::login))
        .route("/products", get(handlers::products::list_products).post(handlers::products::create_product))
        .route(
            "/products/:id",
            get(handlers::products::get_product).delete(handlers::products::delete_product),
        )
        .route("/cart", get(handlers::cart::get_cart).post(handlers::cart::add_to_cart))
        .route("/cart/:product_id", axum::routing::delete(handlers::cart::remove_from_cart))
        .route("/orders/checkout", post(handlers::orders::checkout))
        .route("/orders", get(handlers::orders::list_my_orders));

    let app = Router::new()
        .nest("/api", api_routes)
        .route("/health", get(|| async { "ok" }))
        .layer(CorsLayer::permissive())
        .layer(TraceLayer::new_for_http())
        .with_state(state);

    let addr = "0.0.0.0:3000";
    tracing::info!("listening on {addr}");
    let listener = tokio::net::TcpListener::bind(addr).await.unwrap();
    axum::serve(listener, app).await.unwrap();
}
